# ---------------------------------------------------------------------------------------#
# ----------------------------------------------------------------------------- HEADER --#

"""
:author:
    Jared Webber
    

:synopsis:
    

:description:
    

:applications:
    
:see_also:
   
:license:
    see license.txt and EULA.txt 

"""

# ---------------------------------------------------------------------------------------#
# ---------------------------------------------------------------------------- IMPORTS --#


# ---------------------------------------------------------------------------------------#
# -------------------------------------------------------------------------- FUNCTIONS --#

# def bpy_extension(func):
#     pass
#     def extend_bpy_def(*args, **kwargs):
#         setattr(bpy_type, str(function_to_expose), function_to_expose)
#
#
#
# class RegHandler(object):
#     def __init__(self, bpy_type=None, func=None):
#         print("Init Registration Handler Decorator")
#         self.bpy_type = bpy_type
#         self.func = func
#
#     def __call__(self, type_obj, func, *args, **kwargs):
#         print("Call Registration Handler Decorator")
#         def wrap_thing(*args, **kwargs):
#             setattr(type_obj, str(func.__name__), func)
# --------------------------------------------------------------------------------------#
# ---------------------------------------------------------------------------- CLASSES --#

